package DefinitionSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinitions {
    @Given("^ i am logging")
    public void IAM(){

    }

    @Given("^i am logging$")
    public void iAmLogging() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }
}
